package basic.evaluation;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

import com.hp.hpl.jena.rdf.model.Model;
import com.hp.hpl.jena.rdf.model.ModelFactory;
import com.hp.hpl.jena.rdf.model.impl.PropertyImpl;
import com.hp.hpl.jena.rdf.model.impl.ResourceImpl;

public class AuthorPublicationCreator {
	
	private static int maxTripleNum =100;

	
	public static Model rdfModelCreator(int maxTripleNum){
		int count = 1;
		String predicate = "";
		Model m = ModelFactory.createDefaultModel();
		
		while(count <= maxTripleNum ){
			
			if(count % 50 == 0){
				predicate = "/APlusPublishes";
			}else{
				predicate = "/Publishes";
			}
			
			m.add(new ResourceImpl("http://myexample.org/Author" + count), new PropertyImpl("http://myexample.org" + predicate), 
					new ResourceImpl("http://myexample.org/Publication" + count));
			m.add(new ResourceImpl("http://myexample.org/Author" + count), new PropertyImpl("http://myexample.org" + predicate), 
					new ResourceImpl("http://myexample.org/Publication" + (count+1)));
			m.add(new ResourceImpl("http://myexample.org/Author" + count), new PropertyImpl("http://myexample.org" + predicate), 
					new ResourceImpl("http://myexample.org/Publication" + (count+2)));
			m.add(new ResourceImpl("http://myexample.org/Author" + count), new PropertyImpl("http://myexample.org" + predicate), 
					new ResourceImpl("http://myexample.org/Publication" + (count+3)));
			
			count ++;
		}
		
		return m;		
	}
	
	
	public static void modelToFileSaver(){
		Model m = rdfModelCreator(maxTripleNum);
		
		 try {
       	  File file= new File("AuthorPublicationNetwork.rdf");
       	  
       	  m.write(new FileOutputStream(file), "N-TRIPLES");

       	} catch (IOException e) {
       	  e.printStackTrace();
       	}
       
		m.write(System.out, "");	
	}
	
	public static void main(String[] args){
		
		AuthorPublicationCreator a = new AuthorPublicationCreator();
		
//		a.modelToFileSaver();
		
	}

	
}
