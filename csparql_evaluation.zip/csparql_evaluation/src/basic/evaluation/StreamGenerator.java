package basic.evaluation;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


import com.hp.hpl.jena.rdf.model.Model;
import com.hp.hpl.jena.rdf.model.ModelFactory;
import com.hp.hpl.jena.rdf.model.Property;
import com.hp.hpl.jena.rdf.model.RDFNode;
import com.hp.hpl.jena.rdf.model.Resource;
import com.hp.hpl.jena.rdf.model.Statement;
import com.hp.hpl.jena.rdf.model.StmtIterator;
import com.hp.hpl.jena.rdf.model.impl.PropertyImpl;
import com.hp.hpl.jena.rdf.model.impl.ResourceImpl;
import com.hp.hpl.jena.util.FileManager;
import eu.larkc.csparql.cep.api.RdfQuadruple;
import eu.larkc.csparql.cep.api.RdfStream;

public class StreamGenerator extends RdfStream implements Runnable {

//	static final String inputFileName = "waves_chlorine.rdf";
//	static final String inputFileName = "chlorine_1G.rdf";
//	static final String inputFileName = "waves_flows.rdf";
//	static final String inputFileName = "waves_level.rdf";
//	static final String inputFileName = "waves_pressure.rdf";
	static final String inputFileName = "C:/Users/A612504/Desktop/workspace/waves_data_generator/dataGenerator/flows_7TPE.nt";
//	static final String inputFileName = "C:/Users/A612504/Desktop/workspace/Performance_Evaluation_CSPARQL/waves_chlorine.nt";
	
	private long c = 1L;
	private boolean keepRunning = false;
	private int eventRate = 4;
	private int streamRate = eventRate * 7; 

	protected final Logger logger = LoggerFactory.getLogger(StreamGenerator.class);

	public StreamGenerator(final String iri) {
		super(iri);
	}

	public void pleaseStop() {
		keepRunning = false;
	}

	@Override
	public void run() {

		int type = 3;
		final int RUN_TYPE_1 = 1;
		final int RUN_TYPE_2 = 2;
		final int RUN_TYPE_3 = 3;

		switch (type) {

		
		/*
		 * RUN_TYPE_1: Unordered traversal
		 * RUN_TYPE_2: Generated in memory
		 * RUN_TYPE_3: Ordered traversal
		 */	
		case RUN_TYPE_1:
			
//			warmUpExecutorType1();
			runType1();
			
			break;

		case RUN_TYPE_2:

			warmUpExecutorType2();
			runType2();

			break;
			
		case RUN_TYPE_3:

			try {
				runType3();
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}

			break;
			
			

		default:
			System.exit(0);
			break;
		}
	}

	

/**
 * Generated stream from existing file	
 */
	public void runType1() {
		keepRunning = true;
		
		int eventCounter = 0;
		long eventTimeStamp;
		long tripleCounter = 0;
		long totalTriple = 0;
		long t1, t2;
		long tStart, tEnd;
		Model model = ModelFactory.createDefaultModel();
		model = fileToModelConverter();
		StmtIterator iter = model.listStatements();

		t1 = tStart = System.currentTimeMillis();
		
		while (keepRunning && (iter.hasNext())) {
						
			// tripleCounter =(((tripleCounter == 10000))?0:tripleCounter);
			Statement stmt = iter.nextStatement(); // get next statement
			Resource subject = stmt.getSubject(); // get the subject
			Property predicate = stmt.getPredicate(); // get the predicate
			RDFNode object = stmt.getObject(); // get object

			eventTimeStamp = System.nanoTime();
			
			if (eventCounter == 7){
				eventCounter = 0;
				eventTimeStamp = System.currentTimeMillis();				
			}
	
			final RdfQuadruple q = new RdfQuadruple(subject.toString(), predicate.toString(), object.toString(),
					eventTimeStamp);
			this.put(q);
			
			
			System.out.println("+++++++++"+subject.toString()+ predicate.toString() + object.toString()+"+++++++++");
						
			tripleCounter++;
			totalTriple++;
			eventCounter ++;
			
			if (tripleCounter == streamRate) {
				t2 = System.currentTimeMillis();
				try {
					Thread.sleep((1000 - (t2 - t1)));
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
				System.out.println( "***" + tripleCounter/7 + " events have been detected, " 
						+ tripleCounter + " triples have been completely updated, time spent: " + (t2 - t1) + "***");
				t1 = System.currentTimeMillis();
				tripleCounter = 0;
			}
			totalTriple++;
		}
		tEnd = System.currentTimeMillis();
		System.out.println("System spent --- " + (tEnd - tStart) + " --- to update " + totalTriple + " triples ");
	}

	
	/**
	 * Generat stream directly	
	 */	
	public void runType2() {
		boolean keepRunning = true;
		String predicate = "/Publishes";
		long tripleCounter = 0;
		long t1, t2, tStart;

		this.c = 1L;

		tStart = System.currentTimeMillis();
		t1 = System.currentTimeMillis();

		while (keepRunning && (tripleCounter < streamRate)) {

			// Each 200 triples contains a APlusPublishes
			predicate = (((c % 50 == 0)) ? "/APlusPublishes" : "/Publishes");

			// System.currentTimeMillis() for rate <= 1000;
			// System.nanoTime() for rate > 1000;
			final RdfQuadruple q = new RdfQuadruple(super.getIRI() + "/Author" + this.c,
					"http://myexample.org" + predicate, super.getIRI() + "/Publication" + this.c, System.nanoTime());
			this.put(q);
			final RdfQuadruple q1 = new RdfQuadruple(super.getIRI() + "/Publication" + this.c,
					"http://myexample.org/CitedBy", "http://myexample.org/Author" + this.c + 1, System.nanoTime());
			this.put(q1);
			final RdfQuadruple q2 = new RdfQuadruple(super.getIRI() + "/Publication" + this.c,
					"http://myexample.org/CitedBy", "http://myexample.org/Author" + this.c + 2, System.nanoTime());
			this.put(q2);
			final RdfQuadruple q3 = new RdfQuadruple(super.getIRI() + "/Publication" + this.c,
					"http://myexample.org/CitedBy", "http://myexample.org/Author" + this.c + 3, System.nanoTime());
			this.put(q3);
			c++;
			tripleCounter = tripleCounter + 4;
			if (tripleCounter == streamRate) {
				try {
					t2 = System.currentTimeMillis();
					// System.out.println((t2-t1));
					Thread.sleep((1000 - (t2 - t1)));
					// Thread.sleep(1000);
					System.out.println(tripleCounter + " triples been completely updated, time spent: " + (t2 - t1));
					t1 = System.currentTimeMillis();
					tripleCounter = 0;

					// c = (((tStart - t2)>=6000)? 1L:c );

				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}

		}

	}
	

	
	public void runType3() throws IOException {
		
		long tripleCounter = 0;
		long t1, t2;
		final String SEPARATOR = " ";	
		final String REGEX = "^\"";
		String strLine, sujet, predicate, object;
		
		FileInputStream fInStream = new FileInputStream(inputFileName);
		BufferedReader br = new BufferedReader(new InputStreamReader(fInStream));
		
		t1 = System.currentTimeMillis();
		while ((strLine = br.readLine()) != null)   {


			String[] strLine1=strLine.split(SEPARATOR); 
			
//			System.out.println(strLine1[0] + strLine1[1] + strLine1[2]);
			
			sujet = strLine1[0].replaceAll("^.*\\<", "").replaceAll(">.*", "");
			predicate = strLine1[1].replaceAll("^.*\\<", "").replaceAll(">.*", "");
			
			
			Pattern pat = Pattern.compile(REGEX);
	        Matcher mat = pat.matcher(strLine1[2]);
	        
	        if (mat.find()) {
	            object = strLine1[2].replaceAll("<","").replaceAll(">", "");
	        }
	        else { object = strLine1[2].replaceAll("^.*\\<", "").replaceAll(">.*", "");
	        }
			
			final RdfQuadruple q = new RdfQuadruple(sujet, predicate, object,
					System.currentTimeMillis());
			this.put(q);
			
			tripleCounter ++;
			
			if(tripleCounter == streamRate){
				
				t2 = System.currentTimeMillis();
				try {
					Thread.sleep((1000 - (t2 - t1)));
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
				
				System.out.println( "***" + tripleCounter/7 + " events have been detected, " 
						+ tripleCounter + " triples have been completely updated, time spent: " + (t2 - t1) + "***");
				t1 = System.currentTimeMillis();
				tripleCounter = 0;
			}	
		}
		br.close();	
	}
	
	
	
	

	public void warmUpExecutorType1() {
		long tWarmUpStart, tWarmUpEnd;
		long t1, t2;
		long tripleCounter = 0;

		t1 = System.currentTimeMillis();
		tWarmUpStart = System.currentTimeMillis();
		tWarmUpEnd = System.currentTimeMillis();
		System.out.println("----------------------------------- ");
		System.out.println("--------- Warm up started --------- ");
		System.out.println("----------------------------------- ");

//		while ((tWarmUpEnd - tWarmUpStart) <= 20000) {
		while ((tWarmUpEnd - tWarmUpStart) <= 10000) {


			long t = System.currentTimeMillis();
			final RdfQuadruple q = new RdfQuadruple("http://localhost:80/waves/stream/1i/sh",
					"http://knoesis.wright.edu/ssw/sensor", "http://xxx.com/id/",
					t);
			this.put(q);
			
			final RdfQuadruple q1 = new RdfQuadruple("http://localhost:80/waves/stream/1i/sh",
					"http://knoesis.wright.edu/ssw/unit", "",
					t);
			this.put(q1);

			final RdfQuadruple q2 = new RdfQuadruple("http://localhost:80/waves/stream/1i/sh",
					"http://knoesis.wright.edu/ssw/value", "\"0.12^^xsd:double\"",
					t);
			this.put(q2);
			
			final RdfQuadruple q3 = new RdfQuadruple("http://localhost:80/waves/stream/1i/sh",
					"http://www.w3.org/1999/02/22-rdf-syntax-ns#type", "http://knoesis.wright.edu/ssw/SensorOutput",
					t);
			this.put(q3);
			
			
			
			this.c = this.c +4;
			tripleCounter = tripleCounter = tripleCounter + 4;

			tWarmUpEnd = System.currentTimeMillis();

			if (tripleCounter == streamRate) {
				try {
					t2 = System.currentTimeMillis();
					Thread.sleep((1000 - (t2 - t1)));
					System.out.println(tripleCounter + " triples been completely updated, time spent: " + (t2 - t1));
					t1 = System.currentTimeMillis();
					tripleCounter = 0;
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
		}

		System.out.println("------------------------------------");
		System.out.println("--------- Warm up finished ---------");
		System.out.println("------------------------------------");

		try {// Make sure the sleep time > step
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		System.gc();
	}
	
	
	
	
	
	public void warmUpExecutorType2() {
		long tWarmUpStart, tWarmUpEnd;
		long t1, t2;
		long tripleCounter = 0;

		t1 = System.currentTimeMillis();
		tWarmUpStart = System.currentTimeMillis();
		tWarmUpEnd = System.currentTimeMillis();
		System.out.println("----------------------------------- ");
		System.out.println("--------- Warm up started --------- ");
		System.out.println("----------------------------------- ");

		while ((tWarmUpEnd - tWarmUpStart) <= 10000) {

			// Each 200 triples contains a APlusPublishes
			final RdfQuadruple q = new RdfQuadruple(super.getIRI() + "/Author" + this.c,
					"http://myexample.org/Publishes", super.getIRI() + "/Publication" + this.c,
					System.currentTimeMillis());
			this.put(q);

			this.c++;
			tripleCounter++;

			tWarmUpEnd = System.currentTimeMillis();

			if (tripleCounter == streamRate) {
				try {
					t2 = System.currentTimeMillis();
					Thread.sleep((1000 - (t2 - t1)));
					System.out.println(tripleCounter + " triples been completely updated, time spent: " + (t2 - t1));
					t1 = System.currentTimeMillis();
					tripleCounter = 0;
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
		}

		try {// Make sure the sleep time > step
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		System.gc();
	}

	
	

	public static Model fileToModelConverter() {

		long t1, t2;

		Model m = ModelFactory.createDefaultModel();

		InputStream in = FileManager.get().open(inputFileName);
		t1 = System.currentTimeMillis();
		
		m.read(in, "");

		t2 = System.currentTimeMillis();
		System.out.println("System has spent --- " + (t2 - t1) + " --- to convert the data into model");

//		m.write(System.out, "");
		return m;
	}

	public static void rdfFileCreator_1(long maxFileSize) {

		int i = 1;
		long t1, t2;
		String predicate = "/Publishes";
		Model m = ModelFactory.createDefaultModel();

		t1 = System.currentTimeMillis();

		while (i <= maxFileSize) {

			predicate = (((i % 50 == 0)) ? "/APlusPublishes" : "/Publishes");

			m.add(new ResourceImpl("http://myexample.org/stream/Author" + i),
					new PropertyImpl("http://myexample.org/stream" + predicate),
					new ResourceImpl("http://myexample.org/stream/Publication" + i));
			m.add(new ResourceImpl("http://myexample.org/stream/Publication" + i),
					new PropertyImpl("http://myexample.org/stream/CitedBy"),
					new ResourceImpl("http://myexample.org/stream/Author" + i + 1));
			m.add(new ResourceImpl("http://myexample.org/stream/Publication" + i),
					new PropertyImpl("http://myexample.org/stream/CitedBy"),
					new ResourceImpl("http://myexample.org/stream/Author" + i + 2));
			m.add(new ResourceImpl("http://myexample.org/stream/Publication" + i),
					new PropertyImpl("http://myexample.org/stream/CitedBy"),
					new ResourceImpl("http://myexample.org/stream/Author" + i + 3));
			i++;
		}

		try {
			File file = new File(inputFileName);

			m.write(new FileOutputStream(file), "");

		} catch (IOException e) {
			e.printStackTrace();
		}
		t2 = System.currentTimeMillis();
		System.out.println("rdfFileCreator_1 spends --- " + (t2 - t1) + " --- to creat the file");
	}

	public static void rdfFileCreator_2(long maxFileSize) throws IOException {

		int i = 1;
		long t1, t2;

		String predicate = "/Publishes";

		File fout = new File(inputFileName);
		FileOutputStream fos = new FileOutputStream(fout);
		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(fos));

		t1 = System.currentTimeMillis();
		while (i < maxFileSize) {

			predicate = (((i % 50 == 0)) ? "/APlusPublishes" : "/Publishes");

			bw.write("http://myexample.org/stream/Author" + i + " " + "http://myexample.org/stream" + predicate + " "
					+ "http://myexample.org/stream/Publication" + i);
			bw.newLine();
			bw.write("http://myexample.org/stream/Publication" + i + " " + "http://myexample.org/stream/CitedBy" + " "
					+ "http://myexample.org/stream/Author" + (i + 1));
			bw.newLine();
			bw.write("http://myexample.org/stream/Publication" + i + " " + "http://myexample.org/stream/CitedBy" + " "
					+ "http://myexample.org/stream/Author" + (i + 2));
			bw.newLine();
			bw.write("http://myexample.org/stream/Publication" + i + " " + "http://myexample.org/stream/CitedBy" + " "
					+ "http://myexample.org/stream/Author" + (i + 3));
			bw.newLine();
			i++;
		}

		bw.close();
		t2 = System.currentTimeMillis();
		System.out.println("rdfFileCreator_2 spends --- " + (t2 - t1) + " --- to creat the file");
	}
}
