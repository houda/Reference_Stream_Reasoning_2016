package basic.evaluation;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.RandomAccessFile;
import java.nio.MappedByteBuffer;
import java.nio.channels.FileChannel;
import java.util.zip.GZIPInputStream;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import eu.larkc.csparql.cep.api.RdfQuadruple;
import eu.larkc.csparql.cep.api.RdfStream;


public class  InitializationSpeedTest {

	private static int i;
	
//	public static void main(String[] args){
//		System.out.println("Current time: "+ System.currentTimeMillis());
//		for(i=0;i<=100000000;i++)
//		{
//		 RdfQuadruple q2 = new RdfQuadruple("http://myexample.org//Publication",
//	            	"http://myexample.org/CitedBy", "http://myexample.org/Author", System.currentTimeMillis());
//		}
//		System.out.println("Current time: "+ System.currentTimeMillis());
//		
//	}
	public static void mapChannel() throws IOException {
        long t1 = System.currentTimeMillis();
        FileInputStream in = new FileInputStream("C:/Users/A612504/Desktop/PHD/Test_Data/SRBench_Data/Charley/rdf/4UT01_2004_8_9.n3");
        long size = in.available();
        RandomAccessFile out = new RandomAccessFile("C:/Users/A612504/Desktop/PHD/Test_Data/SRBench_Data/Charley/rdf/4UT01_2004_8_10.n3", "rw");
        FileChannel inc = in.getChannel();
        MappedByteBuffer bf = inc.map(FileChannel.MapMode.READ_ONLY, 0, size);
        FileChannel outc = out.getChannel();
        MappedByteBuffer outbf = outc.map(FileChannel.MapMode.READ_WRITE, 0, size);
        outbf.put(bf);
        inc.close();
        outc.close();
        in.close();
        out.close();
        long t2 = System.currentTimeMillis();
        System.out.println(t2 - t1);
    }
	
	public static void stream() throws FileNotFoundException, IOException {  
        Long startTime = System.currentTimeMillis();  
        String str;
        BufferedReader reader = getReader(new File("C:/Users/A612504/Desktop/PHD/Test_Data/SRBench_Data/Charley/rdf/4UT01_2004_8_9.n3"));  
  
        String line;  
        while ((line = reader.readLine()) != null) {  
            str = reader.readLine();
//            System.out.println(str);
        }  
        Long estimatedTime = System.currentTimeMillis() - startTime;  
        System.out.printf("stream Diff: %d ms\n", estimatedTime);  
  
	}
        
    public static BufferedReader getReader(File f) throws FileNotFoundException, IOException {  
        BufferedReader reader = null;  
        if (f.getName().endsWith(".gz")) {  
            reader = new BufferedReader(new InputStreamReader(new GZIPInputStream(new FileInputStream(f))));  
        } else {  
            reader = new BufferedReader(new InputStreamReader(new FileInputStream(f)));  
        }  
        return reader;  
    }    
        
        
     
	public static void main(String[] args) throws IOException{
        stream(); 
//		 mapChannel();
	}
}



