package basic.evaluation;
/*
 * @(#)ANGenerator.java   
 * Generate the Author-Publication-Network
 * @(#) $Id$
 */

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import eu.larkc.csparql.cep.api.RdfQuadruple;
import eu.larkc.csparql.cep.api.RdfStream;


public class ANGenerator extends RdfStream implements Runnable {

	/** The logger. */
	protected final Logger logger = LoggerFactory
			.getLogger(ANGenerator.class);	

	private int c = 1;
	private int count = 0;
	private final int sleepRate1 = 10;
//	private final int sleepRate2 = 100;
	private String predicate ="/Publishes";
	private boolean keepRunning = false;

	public ANGenerator(final String iri) {
		super(iri);
	}

	public void pleaseStop() {
		keepRunning = false;
	}

	@Override
	public void run() {

//        DateFormat df = new SimpleDateFormat("dd:MM:yy:HH:mm:ss");
		keepRunning = true;
		
		while (keepRunning) {
			
			//Each 200 triples contains a APlusPublishes
			predicate=(((c % 50 == 0))?"/APlusPublishes":"/Publishes");
			
			
			final RdfQuadruple q = new RdfQuadruple(super.getIRI()+"/Author"+ this.c,
					"http://myexample.org"+predicate, super.getIRI()+"/Publication" + this.c, System.currentTimeMillis());
			this.put(q);
			try {
				Thread.sleep(sleepRate1);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}	
			
//			System.out.println(q.toString()+"-->"+df.format(q.getTimestamp()));
						
			final RdfQuadruple q1 = new RdfQuadruple(super.getIRI()+"/Publication" + this.c,
	            	"http://myexample.org/CitedBy", "http://myexample.org/Author" + this.c+1, System.currentTimeMillis());
			this.put(q1);
			try {
				Thread.sleep(sleepRate1);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			
			final RdfQuadruple q2 = new RdfQuadruple(super.getIRI()+"/Publication" + this.c,
	            	"http://myexample.org/CitedBy", "http://myexample.org/Author" + this.c+2, System.currentTimeMillis());
			this.put(q2);
			try {
				Thread.sleep(sleepRate1);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			
			final RdfQuadruple q3 = new RdfQuadruple(super.getIRI()+"/Publication" + this.c,
	            	"http://myexample.org/CitedBy", "http://myexample.org/Author" + this.c+3, System.currentTimeMillis());
			this.put(q3);
			try {
				Thread.sleep(sleepRate1);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			c ++ ;
			
			count = count + 4;
//			if (count == 900){
//			try{count = 0;
//				Thread.sleep(sleepRate2);
//			}catch(InterruptedException e){
//				e.printStackTrace();
//			}
//			}
			
		}
	}
}

