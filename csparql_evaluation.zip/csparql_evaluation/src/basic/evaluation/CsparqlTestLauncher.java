package basic.evaluation;

import java.text.ParseException;

import eu.larkc.csparql.cep.api.RdfStream;
import eu.larkc.csparql.engine.CsparqlEngine;
import eu.larkc.csparql.engine.CsparqlEngineImpl;
import eu.larkc.csparql.engine.CsparqlQueryResultProxy;


public class CsparqlTestLauncher {

	/**
	 * @param args
	 */
	public static void main(String[] args) {

		final int STREAM_CHECK = 0;
		final int TEST_QUERY_1 = 1;
		final int TEST_QUERY_2 = 2;
		final int TEST_QUERY_3 = 3;
		final int TEST_QUERY_4 = 4;
		final int TEST_QUERY_5 = 5;
		final int TEST_QUERY_6 = 6;
		
		//Waves data, 4 triples/event
		final int WAVES_QUERY_7 = 7;
		final int WAVES_QUERY_8 = 8;
		final int WAVES_QUERY_9 = 9;
		
		//Waves data, 7 triples/event
		final int WAVES_QUERY_10 = 10;
		final int WAVES_QUERY_11 = 11;
		final int WAVES_QUERY_12 = 12;
		final int WAVES_QUERY_13 = 13;
		
		int key = 4;

		String streamURI = "http://myexample.org/stream";
		String streamURI1 = "http://myexample.org/stream1";
		String streamURI2 = "http://myexample.org/stream2";
		String streamURI3 = "http://myexample.org/stream3";
		String streamURI4 = "http://myexample.org/stream4";
		
		String wavesStreamURI = "http://waves.org/stream";

		String query = null;
		
		RdfStream tg = null;
		RdfStream tg1 = null;
		RdfStream tg2 = null;
		RdfStream tg3 = null;
		RdfStream tg4 = null;
		
		
		switch (key) {
			
		case STREAM_CHECK:
			query = "REGISTER QUERY TestQuery0 AS "
					+ " PREFIX li: <http://localhost:80/waves/stream/1i/> " 
					+ " PREFIX ssn: <http://purl.oclc.org/NET/ssnx/ssn/>" 
					+ " PREFIX ns: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>"
					+ " PREFIX xsd: <http://www.w3.org/2001/XMLSchema#>"
					+ " PREFIX cuahsi: <http://his.cuahsi.org/ontology/>"
					+ " PREFIX waves: <http://ontology.waves.org/>"
					+ " PREFIX qudt: <http://data.nasa.gov/qudt/owl/qudt/>"
                + " SELECT (SUM(?chlorineValue) AS ?sum)  "
//                + " SELECT ?chlorineValue"
				+ " FROM STREAM <http://myexample.org/stream> [RANGE 1s STEP 1s] " 
//				+ " FROM STREAM <http://myexample.org/stream1> [RANGE 1s STEP 1s] " 
				+ " WHERE { "
//              + " ?author1 ex:APlusPublishes ?publication .  "
//              + " ?publication ex:CitedBy ?author2 . "
				+ "	?sensor ssn:producedBy ?sensorId ;"
				+ "			ssn:hasValue ?observation ."
				+ " ?observation qudt:numericValue ?chlorineValue . "
				+ " } ";
//			tg = new ANGenerator(streamURI);
			
			tg = new StreamGenerator(streamURI);
//			tg1 = new HyperRateTestGenerator(streamURI1);
		
		break;	
		
		case TEST_QUERY_1: //rate_max = 50000, for window size testing, rate = 1000
			
			query = "REGISTER QUERY TestQuery1 AS "
					+ " PREFIX ex: <http://myexample.org/> "
                    + " SELECT DISTINCT ?publication "
					+ " FROM STREAM <http://myexample.org/stream> [RANGE 1s STEP 1s] " 
					+ " FROM STREAM <http://myexample.org/stream1> [RANGE 2s STEP 1s] " 
//					+ " FROM STREAM <http://myexample.org/stream2> [RANGE 1s STEP 1s] " 
//					+ " FROM STREAM <http://myexample.org/stream3> [RANGE 1s STEP 1s] " 
//					+ " FROM STREAM <http://myexample.org/stream4> [RANGE 1s STEP 1s] " 
					+ " WHERE { "
                    + " ?author1 ex:APlusPublishes ?publication .  "
                    + " ?publication ex:CitedBy ?author2 . "
                    + "} ";

//			tg = new ANGenerator(streamURI);
			
			tg = new StreamGenerator(streamURI);
//			tg1 = new HyperRateTestGenerator(streamURI1);
//			tg2 = new HyperRateTestGenerator(streamURI2);
//			tg3 = new HyperRateTestGenerator(streamURI3);
//			tg4 = new HyperRateTestGenerator(streamURI4);


		break;
		
		case TEST_QUERY_2:
			// 5 result for window range = 1s <=> 1000 triples/s, rate_max = 37000
			query = "REGISTER QUERY TestQuery2 AS "
					+ " PREFIX ex: <http://myexample.org/> "
                    + " SELECT DISTINCT ?publication (COUNT(?publication) AS ?citedTimes) "
					+ " FROM STREAM <http://myexample.org/stream> [RANGE 1s STEP 1s] " 
//					+ " FROM STREAM <http://myexample.org/stream1> [RANGE 1s STEP 1s] " 
//					+ " FROM STREAM <http://myexample.org/stream2> [RANGE 1s STEP 1s] " 
//					+ " FROM STREAM <http://myexample.org/stream3> [RANGE 1s STEP 1s] " 
//					+ " FROM STREAM <http://myexample.org/stream4> [RANGE 1s STEP 1s] " 
					+ " WHERE { "
                    + " ?author1 ex:APlusPublishes ?publication .  "
                    + " ?publication ex:CitedBy ?author2 . } "
                    + " GROUP BY ?publication "
                    + " ORDER BY ASC(?publication) ";

//			tg = new ANGenerator(streamURI);
			
			tg = new StreamGenerator(streamURI);
//			tg1 = new HyperRateTestGenerator(streamURI1);
//			tg2 = new HyperRateTestGenerator(streamURI2);
//			tg3 = new HyperRateTestGenerator(streamURI3);
//			tg4 = new HyperRateTestGenerator(streamURI4);

		break;
			
		
		case TEST_QUERY_3: //rate_max = 25000
	
			query = "REGISTER QUERY TestQuery3 COMPUTED EVERY 1s AS "
					+ " PREFIX ex: <http://myexample.org/> "
                    + " SELECT ?publication "
//					+ " CONSTRUCT {?author1 ex:APlusPublishes ?publication }"
					+ " FROM STREAM <http://myexample.org/stream> [RANGE 1s STEP 1s] " 
//					+ " FROM STREAM <http://myexample.org/stream1> [RANGE 1s STEP 1s] " 
//					+ " FROM STREAM <http://myexample.org/stream2> [RANGE 1s STEP 1s] " 
//					+ " FROM STREAM <http://myexample.org/stream3> [RANGE 1s STEP 1s] " 
//					+ " FROM STREAM <http://myexample.org/stream4> [RANGE 1s STEP 1s] " 
					+ " WHERE { "
                    + " ?author1 ex:APlusPublishes ?publication .  "
                    + " ?publication ex:CitedBy ?author2 . "
                    + " FILTER ( regex(str(?publication), '00$', 'i') "
                    + " || ( regex(str(?publication), '50$', 'i')) "
                    + " && (?author1 != ?author2) ) "
                    + "} "
                    + " GROUP BY ?publication ";
//			tg = new ANGenerator(streamURI);
			
			tg = new StreamGenerator(streamURI);
//			tg1 = new HyperRateTestGenerator(streamURI1);
//			tg2 = new HyperRateTestGenerator(streamURI2);
//			tg3 = new HyperRateTestGenerator(streamURI3);
//			tg4 = new HyperRateTestGenerator(streamURI4);

		break;
		
		case TEST_QUERY_4:	//rate_max = 16000
			
			query = " REGISTER QUERY TestQuery4 AS "
					+" PREFIX ex: <http://myexample.org/> "
					+ "PREFIX f: <http://larkc.eu/csparql/sparql/jena/ext#> "
					+" SELECT ?publication ?referrer (COUNT(?referrer) AS ?citedTimes) "
					+" FROM STREAM <http://myexample.org/stream> [RANGE 1s STEP 1s] "
//					+" FROM STREAM <http://myexample.org/stream1> [RANGE 1s STEP 1s] " 
//					+" FROM STREAM <http://myexample.org/stream2> [RANGE 1s STEP 1s] " 
//					+" FROM STREAM <http://myexample.org/stream3> [RANGE 1s STEP 1s] " 
//					+" FROM STREAM <http://myexample.org/stream4> [RANGE 1s STEP 1s] " 
					+" WHERE { " 
					+" ?author ex:APlusPublishes ?publication . "  
					+" ?publication ex:CitedBy ?referrer . "
					+" FILTER ( regex(str(?referrer), '1$', \"i\") "
					+" || regex(str(?referrer), '2$', \"i\")  "
					+" || regex(str(?referrer), '3$', \"i\")) "
					+" FILTER (f:timestamp(?publication, ex:CitedBy, ?referrer) "
					+" >= f:timestamp(?author, ex:APlusPublishes, ?publication)) "
					+" } "
					+" GROUP BY ?publication";
//			tg = new ANGenerator(streamURI);
			
			tg = new StreamGenerator(streamURI);
//			tg1 = new HyperRateTestGenerator(streamURI1);
//			tg2 = new HyperRateTestGenerator(streamURI2);
//			tg3 = new HyperRateTestGenerator(streamURI3);
//			tg4 = new HyperRateTestGenerator(streamURI4);

		break;
		
		case TEST_QUERY_5:	//rate_max = 16000
			query = "REGISTER QUERY TestQuery5 AS "
					+ " PREFIX ex: <http://myexample.org/> "
					+ " PREFIX f: <http://larkc.eu/csparql/sparql/jena/ext#> "
                    + " SELECT ?publication (COUNT(?publication) AS ?citedTimes) "
					+ " FROM STREAM <http://myexample.org/stream> [RANGE 1s STEP 1s] " 
//					+ " FROM STREAM <http://myexample.org/stream1> [RANGE 1s STEP 1s] " 
//					+ " FROM STREAM <http://myexample.org/stream2> [RANGE 1s STEP 1s] " 
//					+ " FROM STREAM <http://myexample.org/stream3> [RANGE 1s STEP 1s] " 
//					+ " FROM STREAM <http://myexample.org/stream4> [RANGE 1s STEP 1s] " 
					+ " WHERE { "
                    + " { "
                    + "  ?author1 ex:APlusPublishes ?publication .  "
                    + "  ?publication ex:CitedBy ?author2 . "
                    + "  FILTER ( regex(str(?publication), '00$', 'i') )"
					+ "  FILTER (f:timestamp(?publication, ex:CitedBy, ?author2) "
					+ "  >= f:timestamp(?author1, ex:APlusPublishes, ?publication)) "
                    + " } "
                    + " UNION "
                    + " { "
                    + " ?author3 ex:Publishes ?publication. "
                    + " ?publication ex:CitedBy ?author4 .	"
                    + "  FILTER ( regex(str(?publication), '10$', 'i') )"
                    + " } "
                    + " } "
                    + " GROUP BY ?publication "
                    + " HAVING (COUNT(?publication) = 3) " 
                    + " ORDER BY ASC(?publication) ";

//			tg = new ANGenerator(streamURI);
			
			tg = new StreamGenerator(streamURI);
//			tg1 = new HyperRateTestGenerator(streamURI1);
//			tg2 = new HyperRateTestGenerator(streamURI2);
//			tg3 = new HyperRateTestGenerator(streamURI3);
//			tg4 = new HyperRateTestGenerator(streamURI4);
			
		break;
		
		
		case TEST_QUERY_6: 
			query = " REGISTER QUERY TestQuery6 AS "
					+" PREFIX ex: <http://myexample.org/> "
//					+" CONSTRUCT { ?author ?acronym ?researchTrack } "
					+" SELECT ?author ?acronym ?researchTrack "
					+" FROM NAMED STREAM <http://myexample.org> [RANGE 1s STEP 1s] "
					+" FROM <http://localhost:9091/project/csparql-evaluation-data/source/conf-code-data-10mb-rdf-1> "
//					+" FROM <http://localhost:9091/project/csparql-evaluation-data/source/conf-code-data-10mb-nt-2>"
//					+" FROM <http://localhost:9091/project/csparql-evaluation-data/source/conf-code-data-20mb-rdf-1> "
//					+" FROM <http://localhost:9091/project/csparql-evaluation-data/source/conf-code-data-30mb-rdf-1> "
//					+" FROM <http://localhost:9091/project/csparql-evaluation-data/source/conf-code-data-40mb-rdf-1> "
//					+" FROM <http://localhost:9091/project/csparql-evaluation-data/source/conf-code-data-50mb-rdf-1> "
					+ " WHERE { "
					+ " ?author ex:APlusPublishes ?publication ."
					+ " ?publication ex:publishedOn ?conferenceCode ."
					+ " ?conferenceCode ex:hasAcronym ?acronym ;"
					+ " 				ex:hasRanking ?ranking ; "
					+ "					ex:hasResearchTrack ?researchTrack . "
					+ " } ";
			
			tg = new StreamGenerator(streamURI);
			
		break;
			
		case WAVES_QUERY_7: 
			query = " REGISTER QUERY TestQuery7 AS "
					+ " PREFIX li: <http://localhost:80/waves/stream/1i/> "
					+ " PREFIX ssw: <http://knoesis.wright.edu/ssw/>"
					+ " PREFIX ns: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>"
//					+ " PREFIX xsd: <http://www.w3.org/2001/XMLSchema#>"
					+ " SELECT ( MIN(?chlorineValue) AS ?minChlorineValue ) "
					+ "        ( MAX(?chlorineValue) AS ?maxChlorineValue )"
					+ " FROM NAMED STREAM <http://waves.org/stream> [RANGE 1s STEP 1s] "
					+ " WHERE {"
					+ "{  "
					+ "	?sensor ssw:sensor ?sensorId ;"
					+ "			ssw:value ?chlorineValue ."
					+ " FILTER( (?chlorineValue > \"0.2\")&&(?chlorineValue < \"0.25\"))"
					+ " } "
					+ " UNION "
					+ "{?sensor ssw:sensor ?sensorId ;"
					+ "			ssw:value ?chlorineValue ."
					+ " FILTER( (?chlorineValue > \"0.3\"))"
					+ "}"
					+ "}";
			
			tg = new StreamGenerator(wavesStreamURI);

		break;	
		
		
		case WAVES_QUERY_8: 
			query = " REGISTER QUERY TestQuery8 AS "
					+ " PREFIX li: <http://localhost:80/waves/stream/1i/> "
					+ " PREFIX ssw: <http://knoesis.wright.edu/ssw/>"
					+ " PREFIX ns: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>"
					+ " PREFIX xsd: <http://www.w3.org/2001/XMLSchema#>"
//					+ " SELECT ( IF(AVG(?chlorineValue) < 1, 10, 100 ) AS ?chlorinDegree)"
					+ " SELECT (AVG(?flowsValue) AS ?avgFlows)"
					+ "		   	(COUNT(?flowsValue1) AS ?countFlows1)"
					+ " FROM NAMED STREAM <http://waves.org/stream> [RANGE 1s STEP 1s] "
					+ " WHERE {"
					+ "	?sensor ssw:sensor ?sensorId ; "
					+ "			ssw:value ?flowsValue ;"
					+ "			ssw:value ?flowsValue1 ."
					+ "FILTER((?flowsValue1 > \"0.3\"))"
					+ "}";
//					+ "GROUP BY ?sensor";
			
			tg = new StreamGenerator(wavesStreamURI);

		break;	
		
		
		case WAVES_QUERY_9: 
			query = " REGISTER QUERY TestQuery9 AS "
					+ " PREFIX li: <http://localhost:80/waves/stream/1i/> "
					+ " PREFIX ssw: <http://knoesis.wright.edu/ssw/>"
					+ " PREFIX ns: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>"
					+ " PREFIX xsd: <http://www.w3.org/2001/XMLSchema#>"
					+ " CONSTRUCT {?sensor ssw:value ?chlorineValue}"
					+ " FROM NAMED STREAM <http://waves.org/stream> [RANGE 1s STEP 1s] "
					+ " WHERE {"
					+ "	?sensor ssw:sensor ?sensorId ; "
					+ "			ssw:value ?chlorineValue ."
					+ " FILTER((?chlorineValue) > \"0.35\") "
					+ " }";
			
			tg = new StreamGenerator(wavesStreamURI);

		break;	
		
		case WAVES_QUERY_10: 
			
			query = " REGISTER QUERY TestQuery10 AS "
					+ " PREFIX li: <http://localhost:80/waves/stream/1i/> " 
					+ " PREFIX ssn: <http://purl.oclc.org/NET/ssnx/ssn/>" 
					+ " PREFIX ns: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>"
					+ " PREFIX xsd: <http://www.w3.org/2001/XMLSchema#>"
					+ " PREFIX cuahsi: <http://his.cuahsi.org/ontology/>"
					+ " PREFIX waves: <http://ontology.waves.org/>"
					+ " PREFIX qudt: <http://data.nasa.gov/qudt/owl/qudt/>"
					+ " SELECT ?sensor ?chlorineValue "
					+ " FROM NAMED STREAM <http://waves.org/stream> [RANGE 1s STEP 1s] "
					+ " WHERE "
					+ "{  "
					+ "	?sensor ssn:isProducedBy ?sensorId ;" 
					+ "			ssn:hasValue ?observation ." 
					+ " ?observation qudt:numericValue ?chlorineValue . " 
					+ " FILTER( (?chlorineValue < \"0.2\"^^xsd:double) || (?chlorineValue > \"0.5\"^^xsd:double))"
					+ " } ";
			
			
			tg = new StreamGenerator(wavesStreamURI);

		break;	
		
		
		case WAVES_QUERY_11: 
			
			query = " REGISTER QUERY TestQuery11 AS "
					+ " PREFIX li: <http://localhost:80/waves/stream/1i/> " 
					+ " PREFIX ssn: <http://purl.oclc.org/NET/ssnx/ssn/>" 
					+ " PREFIX ns: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>"
					+ " PREFIX ssnp: <http://purl.oclc.org/NET/ssnx/ssn#>"
					+ " PREFIX xsd: <http://www.w3.org/2001/XMLSchema#>"
					+ " PREFIX cuahsi: <http://his.cuahsi.org/ontology/>"
					+ " PREFIX waves: <http://ontology.waves.org/>"
					+ " PREFIX qudt: <http://data.nasa.gov/qudt/owl/qudt/>"
					+ " PREFIX zone: <http://www.zone-waves.fr/2016/sensor#>"
					+ " SELECT ?sector (SUM(?flowsValue) AS ?sumFlows) "
					+ " FROM NAMED STREAM <http://waves.org/stream> [RANGE 1s STEP 1s] "
					+ " FROM <http://localhost:9091/project/waves-test/source/c-users-a612504-desktop-sector2-1>"
					+ " WHERE "
					+ "{  "
					+ "	?sensor ssn:isProducedBy ?sensorId ;"
					+ "			ssn:hasValue ?observation ."
					+ " ?observation qudt:numericValue ?flowsValue . "
					+ " ?sensorId ssnp:onPlatform ?sector . "
					+ " } "
					+ "GROUP BY ?sector";
			
			
			tg = new StreamGenerator(wavesStreamURI);

		break;	
		
		case WAVES_QUERY_12: 
			
			query =" REGISTER QUERY TestQuery12 AS" +
				    " SELECT ?s ?o ?o1 ?o2 ?o3 ?o4 ?o5 ?o6 " +
				    " FROM NAMED STREAM <http://waves.org/stream> [RANGE 1s STEP 1s] " +
					" WHERE{ "+
				  " ?s <http://www.w3.org/1999/02/22-rdf-syntax-ns#type> ?o ; "+
				     " <http://purl.oclc.org/NET/ssnx/ssn/isProducedBy>  ?o1; "+
					 " <http://purl.oclc.org/NET/ssnx/ssn/hasValue> ?o2. "+
				  " ?o2 <http://www.w3.org/1999/02/22-rdf-syntax-ns#type> ?o3; "+
					  " <http://purl.oclc.org/NET/ssnx/ssn/startTime> ?o4; " +
					  " <http://data.nasa.gov/qudt/owl/qudt/unit> ?o5; "+
					  " <http://data.nasa.gov/qudt/owl/qudt/numericValue> ?o6."+
				" } ";
			
			tg = new StreamGenerator(wavesStreamURI);

		break;	
		
		case WAVES_QUERY_13: 
			
			query =" REGISTER QUERY TestQuery12 AS" +
				    " SELECT ?s ?oo " +
				    " FROM NAMED STREAM <http://waves.org/stream> [RANGE 1s STEP 1s] " +
					" WHERE{ "+
				  " ?s <http://purl.oclc.org/NET/ssnx/ssn/isProducedBy>  ?o . "+
				  " ?ss <http://data.nasa.gov/qudt/owl/qudt/numericValue> ?oo . "+
				" } ";
			
			tg = new StreamGenerator(wavesStreamURI);

		break;	
		
		
		
		default:
			System.exit(0);
			break;
		}

		CsparqlEngine engine = new CsparqlEngineImpl();	
		engine.initialize(true);
		engine.registerStream(tg);
	
		final Thread t = new Thread((Runnable) tg);
		t.start();

//		if(tg1 != null){
//			engine.registerStream(tg1);
//			final Thread t1 = new Thread((Runnable) tg1);
//			t1.start();
//		}
//		if(tg2 != null){
//			engine.registerStream(tg2);
//			final Thread t2 = new Thread((Runnable) tg2);
//			t2.start();
//		}
//		if(tg3 != null){
//			engine.registerStream(tg3);
//			final Thread t3 = new Thread((Runnable) tg3);
//			t3.start();
//		}
//		if(tg4 != null){
//			engine.registerStream(tg4);
//			final Thread t4 = new Thread((Runnable) tg4);
//			t4.start();
//		}

	
		CsparqlQueryResultProxy c = null;


		try {
			c = engine.registerQuery(query);
			System.out.println("Query: " + query);
			System.out.println("Query Start Time : " + System.currentTimeMillis());
			} catch (final ParseException ex) {
				System.out.println("errore di parsing: " + ex.getMessage());
			}

		if (c != null) {	
			c.addObserver(new ConsoleFormatter());
			}
		

		try {
			//Engine launched for one hour
			Thread.sleep(3600000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		
		engine.unregisterQuery(c.getId());
		((StreamGenerator) tg).pleaseStop();
//		engine.unregisterStream(tg.getIRI());
//		((HyperRateTestGenerator) tg1).pleaseStop();
//		engine.unregisterStream(tg1.getIRI());
//		((HyperRateTestGenerator) tg2).pleaseStop();
//		engine.unregisterStream(tg2.getIRI());
//		((HyperRateTestGenerator) tg3).pleaseStop();
//		engine.unregisterStream(tg3.getIRI());
//		((HyperRateTestGenerator) tg4).pleaseStop();
//		engine.unregisterStream(tg4.getIRI());
		
		
		System.exit(0);	

	}

}
